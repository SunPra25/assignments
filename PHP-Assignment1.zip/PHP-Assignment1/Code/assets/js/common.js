$("#birthdate").datepicker({
    showOn: "both",
    buttonImage: "/images/calendar.png",
    buttonImageOnly: true,
    yearRange: '1910:2020',
    changeYear: true
});