function Ctrl($scope, $compile, $http) {
    
    $scope.columnDefs = [
        {"mDataProp": "name", "aTargets": [0]},
        {"mDataProp": "email", "aTargets": [1]},
        {"mDataProp": "mobile_no", "aTargets": [2]},
        {"mDataProp": "birthdate", "aTargets": [3]},
        {"mDataProp": "country", "aTargets": [4]},
        {"mDataProp": "description", "aTargets": [5]},
        {"mDataProp": "action", "aTargets": [6], "fnRender": function (data) {
                var _temp = "<center><a href='edit_user/" + data.aData.uid + "' data-toggle='modal' class='glyphicon glyphicon-edit remarks_btn'></i></center>"
                return _temp;
            }}
    ];

    $scope.overrideOptions = {
        "bStateSave": true,
        "bJQueryUI": true,
        "bPaginate": true,
        "bLengthChange": true,
        "bFilter": true,
        "bInfo": true,
        "bDestroy": true,
        "scrollCollapse": true,
        "sscrollX": "10px",
    };

    $scope.url = "../User/get_user_list";
    $scope.searchData = function () {
        $http({
            url: $scope.url,
            method: "POST",
            data: $scope.toSearch,
            headers: {
                'Content-Type': JSON
            },
        }).then(function success(response) {
            if (response.data !== '0') {
                $scope.userData = response.data;
            }
        }, function error(response) {
            alert("error");
        });
    };

  
}