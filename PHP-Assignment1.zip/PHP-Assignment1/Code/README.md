#after downloading change base_url from config file to your folder name which is stored in wamp 

$config['base_url'] = 'http://localhost/Code/';   => $config['base_url'] = 'http://localhost/YOUR FOLDER';


#import database schema from sql file