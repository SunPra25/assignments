<?php

class User extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('user_model');
        $this->load->library('form_validation');
    }

    public function index() {
        redirect(site_url('user/add_user'));
    }

    public function add_user() {
        $this->form_validation->set_rules('name', 'Name', 'trim|required|min_length[3]|max_length[50]');
        $this->form_validation->set_rules('country', 'Country', 'trim|required');
        $this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email');
        $this->form_validation->set_rules('mobile_no', 'Mobile Number', 'trim|required|numeric');
        $this->form_validation->set_rules('description', 'About User', 'trim|required');
        $this->form_validation->set_rules('birthdate', 'Birth Date', 'trim|required');

        $id = 0;
        $msg = 'User Added Successful!';
        $data['title'] = 'Add User';
        $red_url = 'user/add_user';
        $view_page = 'add_user';
        if (!empty($_POST['uid'])) {
            $data['title'] = 'Edit User';
            $msg = 'User Updated Successful!';
            $id = $this->input->post('uid');
            $red_url = 'user/edit_user/' . $id;
            $view_page = 'edit';
        }
        if ($this->form_validation->run() === FALSE) {
            $this->load->view('templates/header', $data);
            $this->load->view($view_page);
            $this->load->view('templates/footer');
        } else {

            if ($this->user_model->set_user_data($id)) {
                $this->session->set_flashdata('msg_success', $msg);
                redirect(site_url($red_url));
            } else {
                $this->session->set_flashdata('msg_error', 'Error! Please try again later.');
                redirect($red_url);
            }
        }
    }

    public function edit_user() {
        $id = $this->uri->segment(3);
        $data['title'] = 'Edit User';
        if (empty($id)) {
            redirect(site_url('user/add_user'));
        }
        $data['user_info'] = $this->user_model->get_user_data($id);
        $this->load->view('templates/header', $data);
        $this->load->view('edit', $data);
        $this->load->view('templates/footer');
    }

    public function user_list() {
        $data['title'] = 'User details';
        $data['user_info'] = $this->user_model->get_user_data();
        $this->load->view('templates/header', $data);
        $this->load->view('user_list', $data);
        $this->load->view('templates/footer');
    }

    public function get_user_list() {
        $query = $this->user_model->get_user_data();
        $list_array = array();
        if (!empty($query)) {
            foreach ($query as $row) {
                $list_array[] = $row;
            }
        }
        $this->output->set_content_type('application/json')
                ->set_output(json_encode($list_array));
    }

}
