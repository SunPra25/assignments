<?php

class User_model extends CI_Model {

    public function get_user_data($id = 0) {
        if ($id === 0) {
            $query = $this->db->select('uid,name,country,email,mobile_no,description,birthdate', false)
                    ->from('user_details');
            $query = $this->db->get();
            return $query->result_array();
        }
        $query = $this->db->get_where('user_details', array('uid' => $id));
        return $query->row_array();
    }

    public function set_user_data($id = 0) {
        $data = array(
            'name' => $this->input->post('name'),
            'country' => $this->input->post('country'),
            'email' => $this->input->post('email'),
            'mobile_no' => $this->input->post('mobile_no'),
            'description' => $this->input->post('description'),
            'birthdate' => $this->input->post('birthdate'),
            'modified_date' => date('Y-m-d H:i:s')
        );

        if ($id == 0) {
            return $this->db->insert('user_details', $data);
        } else {
            $this->db->where('uid', $id);
            $this->session->set_userdata('email', $data['email']);
            return $this->db->update('user_details', $data);
        }
    }

    public function delete_user($id) {
        $this->db->where('uid', $id);
        return $this->db->delete('user_details');
    }

}
