        </div>
    </div>
<div class="container text-center">
    <small class="text-center" style="color:#F26522;">© <?php echo date('Y'); ?></small>
</div>

</body>
</html>