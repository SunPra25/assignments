<html ng-app ='mainApp'>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <!-- jQuery -->
        <script type="text/javascript" src="<?php echo base_url('assets/js/jquery-1.10.2.js') ?>"></script>
        <script type="text/javascript" src="<?php echo base_url('assets/js/jquery-ui.min.js') ?>"></script>
        <script type="text/javascript" src="<?php echo base_url('assets/js/common.js') ?>"></script>
        <link type="text/css" href="<?php echo base_url('assets/css/jquery-ui.css') ?>" rel="stylesheet" />

        <!--Bootstrap-->
        <link rel="stylesheet"  type="text/css" href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css') ?>">
        <script type="text/javascript" src="<?php echo base_url('assets/bootstrap/js/bootstrap.min.js') ?>"></script>

        <!--angular JS -->
        <script type="text/javascript" src="<?php echo base_url('assets/angular/js/angular.js') ?>"></script>
        <script type="text/javascript" src="<?php echo base_url('assets/angular/app/app.js') ?>"></script>


        <!-- DataTables -->
        <script type="text/javascript" charset="utf8" src="<?php echo base_url('assets/js/jquery.dataTables.min.js') ?>"></script>
        <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/jquery.dataTables.css') ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/custom.css') ?>">
        <title>Sample Assignment1</title>

    </head>
    <body>
        <header role="banner">
            <nav class="navbar navbar-default" role="navigation">
                <div class="container-fluid">
                    <div class="navbar-collapse collapse">
                        <ul class="nav navbar-nav navbar-right">
                            <li><a href="<?php echo site_url('user/user_list'); ?>"><strong>User Details<span class="border"></strong></span></a></li>
                            <li><a href="<?php echo site_url('user/add_user'); ?>"><strong>Add User<span class="border"></span></strong></a></li>

                        </ul>
                    </div>
                </div>
            </nav>
        </header>
        <div class="container">    

