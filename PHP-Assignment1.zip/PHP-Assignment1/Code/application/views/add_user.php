<p class="text-danger text-center"><?php echo $this->session->flashdata('verify_msg'); ?></p>
<p class="text-success text-center"><?php echo $this->session->flashdata('msg_success'); ?></p>
<p class="text-danger text-center"><?php echo $this->session->flashdata('msg_error'); ?></p>
<div class="col-sm-offset-2 col-md-offset-2 col-lg-offset-2 col-sm-8 col-md-8 col-lg-8">
    <div id="myTabContent" class="tab-content">
        <?php echo form_open("user/add_user", array("name" => "registrationform", "class" => "form-horizontal", "method" => "POST")); ?>
        <fieldset>
            <div id="legend">
                <legend class=""><?php echo $title; ?></legend>
            </div> 
            <div class="form-group">
                <label class="control-label col-sm-3"  for="name">Name</label>
                <div class="controls col-sm-6">
                    <input type="text" id="name" name="name" placeholder="Name" value="<?php echo set_value('name'); ?>" class="form-control"><small class='text-danger'><?php echo form_error('name'); ?></small>
                </div>
            </div>

            <div class="form-group">
                <label class="control-label col-sm-3"  for="country">Country</label>
                <div class="controls col-sm-6">
                    <input type="text" id="country" name="country" placeholder="Country" value="<?php echo set_value('country'); ?>" class="form-control"><small class='text-danger'><?php echo form_error('country'); ?></small>
                </div>
            </div>

            <div class="form-group">
                <label class="control-label col-sm-3"  for="email">Email ID</label>
                <div class="controls col-sm-6">
                    <input type="email" id="email" name="email" placeholder="Email-ID" value="<?php echo set_value('email'); ?>" class="form-control"><small class='text-danger'><?php echo form_error('email'); ?></small>
                </div>
            </div>

            <div class="form-group">
                <label class="control-label col-sm-3"  for="mobile_no">Mobile No</label>
                <div class="controls col-sm-6">
                    <input type="text" id="mobile_no" name="mobile_no" placeholder="Mobile No" value="<?php echo set_value('mobile_no'); ?>" class="form-control"><small class='text-danger'><?php echo form_error('mobile_no'); ?></small>
                </div>
            </div>

            <div class="form-group">
                <label class="control-label col-sm-3"  for="birthdate">Birth Date</label>
                <div class="controls col-sm-6">
                    <input type="text" id="birthdate" name="birthdate" placeholder="yyyy-mm-dd" value="<?php echo set_value('birthdate'); ?>" class="form-control"><small class='text-danger'><?php echo form_error('birthdate'); ?></small>
                </div>
            </div>

            <div class="form-group">
                <label class="control-label col-sm-3"  for="description">Description</label>
                <div class="controls col-sm-6">
                    <textarea cols="5" rows="4" class="form-control" name="description" /><?php echo set_value('description'); ?></textarea><small class='text-danger'><?php echo form_error('description'); ?></small>
                </div>
            </div>
            <div class="form-group">
                <div class="controls col-sm-offset-3 col-sm-3">
                    <button name="submit" type="submit" class="btn btn-success">Save</button>
                </div>
            </div>
        </fieldset>
        <?php echo form_close(); ?>              
    </div>
