<div class="row">
    <h4 class="col-md-offset-0"><i class="glyphicon glyphicon-star-empty"></i><u><?php echo $title; ?></u></h4> 
</div> 
<div ng-controller="Ctrl" ng-init="searchData()">   
<div class='row'>  
    <table class="table table-striped table-bordered table-hover display" my-table="overrideOptions"
               aa-data="userData"
               ao-column-defs="columnDefs"
               fn-row-callback="myCallback"
               cellspacing="0" width="100%">
        <thead>
            <tr>
                <th class="middletext" >Name</th>
                <th class="middletext" >Email</th>
                <th class="middletext" >Mobile No</th>
                <th class="middletext" >Birth Date</th>
                <th class="middletext" >Country</th>
                <th class="middletext" >Description</th>
                <th class="middletext" >Action</th>
            </tr>
        </thead>
        <tbody>
        </tbody>
    </table>
</div>
</div> 
<script type="text/javascript" src="../../assets/angular/directive/dtable.js"></script>
<script type="text/javascript" src="../../assets/angular/controller/common.js"></script>